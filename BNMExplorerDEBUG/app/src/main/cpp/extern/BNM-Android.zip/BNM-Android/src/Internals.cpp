#include <Internals.hpp>

namespace BNM::Internal {
    States states{};
    void *il2cppLibraryHandle{};

    void *BasicFinder(const char *name, void *userData) { return BNM_dlsym(*(void **)userData, name); }

    Loading::MethodFinder currentFinderMethod = BasicFinder;
    void *currentFinderData = &il2cppLibraryHandle;

    // A list with variables from the il2cpp VM
    VMData vmData{};

    // il2cpp methods to avoid searching for them every BNM query
    Il2CppMethods il2cppMethods{};

    BNM::ForwardList<void(*)()> onIl2CppLoaded{};

    std::string_view constructorName = BNM_OBFUSCATE(".ctor");
    BNM::Class customListTemplateClass{};
    std::map<uint32_t, BNM::Class> customListsMap{};
    int32_t finalizerSlot = -1;

#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
    std::shared_mutex customListsMapMutex{};
#endif

#ifdef BNM_CLASSES_MANAGEMENT
    std::unordered_set<BNM::IL2CPP::Il2CppClass *> bnmAllocatedClasses{};
    std::unordered_set<BNM::IL2CPP::Il2CppClass **> bnmAllocatedInnerLists{};
#endif

    void *BNM_il2cpp_init_origin{};
#if UNITY_VER >= 192
    int (*old_BNM_il2cpp_init)(const char *){};
#else
    // il2cpp_init returned void before Unity 2019.2
    void (*old_BNM_il2cpp_init)(const char *){};
#endif

    void *BNM_Class$$FromIl2CppType_origin{};
    IL2CPP::Il2CppClass *(*old_BNM_Class$$FromIl2CppType)(IL2CPP::Il2CppReflectionType*){};

#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
    std::shared_mutex loadingMutex{};
#endif

#ifdef BNM_CLASSES_MANAGEMENT
    namespace ClassesManagement {
#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
        std::shared_mutex classesFindAccessMutex{};
#endif
        // A list with all the classes that BNM should create/modify
        std::vector<MANAGEMENT_STRUCTURES::CustomClass *> *classesManagementVector = nullptr;

        IL2CPP::Il2CppClass *(*old_Class$$FromIl2CppType)(IL2CPP::Il2CppType *type){};

        IL2CPP::Il2CppClass *(*old_Type$$GetClassOrElementClass)(IL2CPP::Il2CppType *type){};

        IL2CPP::Il2CppClass *(*old_Class$$FromName)(IL2CPP::Il2CppImage *image, const char *ns, const char *name){};

#if UNITY_VER <= 174
        IL2CPP::Il2CppImage *(*old_GetImageFromIndex)(IL2CPP::ImageIndex index){};
#endif
        BNMClassesMap bnmClassesMap{};
    }
#endif
}

using namespace BNM;

#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
static std::shared_mutex fallbackAssembliesMutex{};
#endif
static std::vector<BNM::IL2CPP::Il2CppAssembly *> fallbackAssembliesList{};

std::vector<BNM::IL2CPP::Il2CppAssembly *> &Internal::GetAllAssemblies() {
    // 1. Direct internal il2cpp::vm::Assembly::GetAllAssemblies if available
    if (Internal::il2cppMethods.Assembly$$GetAllAssemblies) {
        auto assembliesPtr = Internal::il2cppMethods.Assembly$$GetAllAssemblies();
        if (assembliesPtr) return *assembliesPtr;
    }

    // 2. Fallback to exported il2cpp_domain_get_assemblies API (Issues #177 & #179 fix)
    if (Internal::il2cppMethods.il2cpp_domain_get_assemblies && Internal::il2cppMethods.il2cpp_domain_get) {
        auto domain = Internal::il2cppMethods.il2cpp_domain_get();
        if (domain) {
            size_t count = 0;
            auto assembliesArray = Internal::il2cppMethods.il2cpp_domain_get_assemblies(domain, &count);
            if (assembliesArray && count > 0) {
#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
                std::unique_lock lock(fallbackAssembliesMutex);
#endif
                fallbackAssembliesList.assign((IL2CPP::Il2CppAssembly **)assembliesArray, (IL2CPP::Il2CppAssembly **)assembliesArray + count);
                return fallbackAssembliesList;
            }
        }
    }

#ifdef BNM_ALLOW_MULTI_THREADING_SYNC
    std::shared_lock lock(fallbackAssembliesMutex);
#endif
    return fallbackAssembliesList;
}

IL2CPP::Il2CppImage *Internal::TryGetImage(const std::string_view &_name) {
    auto &assemblies = Internal::GetAllAssemblies();

    if (Internal::il2cppMethods.il2cpp_assembly_get_image) for (auto assembly : assemblies) {
        auto currentImage = Internal::il2cppMethods.il2cpp_assembly_get_image(assembly);
        if (!Internal::CompareImageName(currentImage, _name)) continue;
        return currentImage;
    }

    // Transparent Corlib fallback across Unity 5.6 - Unity 6
    // (mscorlib.dll vs System.Private.CoreLib.dll)
    if (_name == BNM_OBFUSCATE_TMP("mscorlib.dll") || _name == BNM_OBFUSCATE_TMP("mscorlib") ||
        _name == BNM_OBFUSCATE_TMP("System.Private.CoreLib.dll") || _name == BNM_OBFUSCATE_TMP("System.Private.CoreLib")) {
        if (Internal::il2cppMethods.il2cpp_get_corlib) {
            return Internal::il2cppMethods.il2cpp_get_corlib();
        }
    }

    return {};
}

IL2CPP::Il2CppClass *Internal::TryGetClassInImage(const IL2CPP::Il2CppImage *image, const std::string_view &_namespace, const std::string_view &_name) {
    if (!image) return nullptr;

#ifdef BNM_CLASSES_MANAGEMENT
    // Get BNM classes
    if (image->nameToClassHashTable == (decltype(image->nameToClassHashTable))-0x424e4d) goto NEW_CLASSES;
#endif

#if UNITY_VER >= 183
    if (Internal::il2cppMethods.il2cpp_image_get_class) {
        size_t typeCount = image->typeCount;

        for (size_t i = 0; i < typeCount; ++i) {
            auto cls = il2cppMethods.il2cpp_image_get_class(image, i);
            if (!cls) continue; // il2cpp_image_get_class may return null for stripped types
            if (cls->declaringType || !cls->flags && strcmp(cls->name, BNM_OBFUSCATE("<Module>")) == 0) continue;
            if (_namespace == cls->namespaze && _name == cls->name) return cls;
        }
    } else
#endif
    {
        std::vector<IL2CPP::Il2CppClass *> classes{};
        Internal::Image$$GetTypes(image, false, &classes);

        for (auto cls : classes) {
            if (!cls) continue;
            Internal::il2cppMethods.Class$$Init(cls);
            if (cls->declaringType) continue;
            if (cls->namespaze == _namespace && cls->name == _name) return cls;
        }
    }

#ifdef BNM_CLASSES_MANAGEMENT
    NEW_CLASSES:
    IL2CPP::Il2CppClass *result = nullptr;
    ClassesManagement::bnmClassesMap.ForEachByImage(image, [&_namespace, &_name, &result](IL2CPP::Il2CppClass *BNM_class) -> bool {
        if (_namespace != BNM_class->namespaze || _name != BNM_class->name) return false;

        result = BNM_class;
        return true;
    });
    return result;
#endif

    return nullptr;
}
Class Internal::TryMakeGenericClass(Class genericType, const std::vector<CompileTimeClass> &templateTypes) {
    if (!vmData.RuntimeType$$MakeGenericType.IsValid()) return {};
    auto monoType = genericType.GetMonoType();
    auto monoGenericsList = Structures::Mono::Array<MonoType *>::Create(templateTypes.size(), true);
    for (IL2CPP::il2cpp_array_size_t i = 0; i < (IL2CPP::il2cpp_array_size_t) templateTypes.size(); ++i)
        (*monoGenericsList)[i] = templateTypes[i].ToClass().GetMonoType();

    Class typedGenericType = vmData.RuntimeType$$MakeGenericType(monoType, monoGenericsList);

    monoGenericsList->Destroy();

    return typedGenericType;
}

MethodBase Internal::TryMakeGenericMethod(const MethodBase &genericMethod, const std::vector<CompileTimeClass> &templateTypes) {
    if (!vmData.RuntimeMethodInfo$$MakeGenericMethod_impl.IsValid() || !genericMethod.GetInfo()->is_generic) return {};
    IL2CPP::Il2CppReflectionMethod reflectionMethod;
    reflectionMethod.method = genericMethod.GetInfo();

    // Il2cpp don't care about it
#ifdef BNM_CHECK_INSTANCE_TYPE
    reflectionMethod.object.klass = BNM::PRIVATE_INTERNAL::GetMethodClass(vmData.RuntimeMethodInfo$$MakeGenericMethod_impl._data);
#endif
    auto monoGenericsList = Structures::Mono::Array<MonoType *>::Create(templateTypes.size(), true);
    for (IL2CPP::il2cpp_array_size_t i = 0; i < (IL2CPP::il2cpp_array_size_t) templateTypes.size(); ++i) (*monoGenericsList)[i] = templateTypes[i].ToClass().GetMonoType();

    MethodBase typedGenericMethod = vmData.RuntimeMethodInfo$$MakeGenericMethod_impl[(void *)&reflectionMethod](monoGenericsList)->method;

    monoGenericsList->Destroy();

    return typedGenericMethod;
}

Class Internal::GetPointer(Class target) {
    if (!vmData.RuntimeType$$MakePointerType.IsValid()) return {};
    return vmData.RuntimeType$$MakePointerType(target.GetMonoType());
}

Class Internal::GetReference(Class target) {
    if (!vmData.RuntimeType$$make_byref_type.IsValid()) return {};
    return vmData.RuntimeType$$make_byref_type[(void *)target.GetMonoType()]();
}